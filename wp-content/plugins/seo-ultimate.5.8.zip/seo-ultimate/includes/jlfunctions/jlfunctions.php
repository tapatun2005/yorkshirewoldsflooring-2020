<?php
/*
JLFunctions Library
Copyright (c)2009-2010 John Lamansky
*/

foreach (array('arr', 'html', 'io', 'md', 'str', 'url', 'web') as $jlfuncfile) {
	include dirname(__FILE__)."/$jlfuncfile.php";
}

?>