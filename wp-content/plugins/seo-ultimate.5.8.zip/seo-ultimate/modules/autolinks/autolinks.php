<?php
/**
 * Deeplink Juggernaut Module
 * 
 * @since 1.8
 */

if (class_exists('SU_Module')) {

class SU_Autolinks extends SU_Module {
	function get_module_title() { return __('Deeplink Juggernaut', 'seo-ultimate'); }
}

}
?>